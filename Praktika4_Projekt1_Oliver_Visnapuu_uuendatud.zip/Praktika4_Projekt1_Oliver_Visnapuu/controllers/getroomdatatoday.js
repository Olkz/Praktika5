const db = require('../config/index');

module.exports = function (app) {
    app.get("/api/room/44/datatoday", function (req, res) {
        res.set('Access-Control-Allow-Origin', '*')
        db.any("SELECT ds.date_time, ds.data AS Sensor_Value, tv.dimension AS Unit, dsmax.max_data_date " +
        "FROM datasensor ds " +
        "INNER JOIN (SELECT max(dsmax.date_time) as max_data_date from datasensor dsmax) dsmax ON " +
        "DATE(ds.date_time - interval '3 hours') = DATE(dsmax.max_data_date) " +
        "INNER JOIN typevalue tv ON ds.id_typevalue = tv.id " +
        "INNER JOIN controller_sensor cs ON ds.id_controllersensor = cs.id " +
        "WHERE cs.room = '44' " +
        "ORDER BY ds.date_time"
        )
            .then(function (data) {
                res.json({
                    status: "success",
                    data,
                });
            })
            .catch((err) => {
                res.json({
                    description: "Can’t find any room",
                    error: err,
                });
            });
    })
};


/*"SELECT ds.date_time, ds.data AS Sensor_Value, tv.dimension AS Unit, dsmax.max_data_date " +
        "FROM datasensor ds " +
        "INNER JOIN (SELECT max(dsmax.date_time) as max_data_date from datasensor dsmax) dsmax ON " +
        "DATE(ds.date_time) = DATE(dsmax.max_data_date) " +
        "INNER JOIN typevalue tv ON ds.id_typevalue = tv.id " +
        "INNER JOIN controller_sensor cs ON ds.id_controllersensor = cs.id " +
        "WHERE cs.room = '44' " +
        "ORDER BY ds.date_time" */


/*"SELECT ds.date_time, ds.data AS Sensor_Value, tv.dimension AS Unit " +
        "FROM datasensor ds " +
        "INNER JOIN typevalue tv ON ds.id_typevalue = tv.id " +
        "INNER JOIN controller_sensor cs ON ds.id_controllersensor = cs.id " +
        "WHERE cs.room = '44' AND DATE(ds.date_time - interval '3 hours') = '2022-05-12'" +
        "ORDER BY ds.date_time" */