const db = require('../config/index');

module.exports = function (app) {
    app.get("/api/room/:number/sensors/data", function (req, res) {
        res.set('Access-Control-Allow-Origin', '*')
        db.any(
            "SELECT s.id as Sensor_Id, s.sensorname as Sensor_Name, data.data as Data, data.dimension as Data_Dimension, data.date_time as Data_Timestamp " + 
            "FROM sensor s INNER JOIN controller_sensor cs ON cs.id_sensor=s.id " +
            "LEFT JOIN ( " +
	            "SELECT data.id_controllersensor, data.dimension, data.maxid, ds.data, ds.date_time " +
	            "FROM datasensor ds " +
	            "INNER JOIN ( " +
		            "SELECT ds.id_controllersensor, tv.dimension, MAX(ds.id) as maxid " +
		            "FROM datasensor ds " +
		            "INNER JOIN typevalue tv ON " +
		            "ds.id_typevalue = tv.id " +
		            "GROUP BY 1, 2 " +
			        ") data ON " +
	                "data.maxid = ds.id	" +
	            ") data ON " +
            "cs.id = data.id_controllersensor " +
            "WHERE cs.room = " + req.params.number + ":: varchar " +
            "ORDER BY 1"
        )
            .then(function (data) {
                res.json({
                    status: "success",
                    data: data,
                });
            })
            .catch(function (err) {
                return next(err);
            });
    });
};

/*"SELECT s.sensorname FROM sensor s INNER JOIN controller_sensor cs ON cs.id_sensor=s.id " +
            "LEFT JOIN (SELECT ds.id_controllersensor, ds.data, tv.dimension, MAX(ds.date_time) FROM datasensor ds INNER JOIN typevalue tv ON ds.id_typevalue = tv.id GROUP BY 1, 2, 3) dat ON " +
            "cs.id = dat.id_controllersensor" +
            "WHERE controller_sensor.room = " + req.params.number + ":: varchar" */