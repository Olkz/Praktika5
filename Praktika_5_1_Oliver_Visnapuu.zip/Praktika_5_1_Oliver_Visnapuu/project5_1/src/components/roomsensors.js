import React, { Component } from "react";
import axios from 'axios';

export default class roomsensors extends Component {
    state = {
        room_number: '',
        sensors: []
    };

    readData() {
        this.setState({ room_number: this.props.match.params.number })
        axios.get(`http://localhost:8000/api/room/'${this.props.match.params.number}'/sensors/data`)
            .then(res => {
                this.setState({ sensors: res.data.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    componentDidMount() {
        this.readData()
    }

    componentDidUpdate(prevProps) {
        if (prevProps.match.params.number !== this.props.match.params.number) {
            this.readData()
        }
    }

    render() {
        const { room_number, sensors } = this.state;
        if (sensors.length === 0) {
            return (
                <div>
                    <h1> Room: {room_number}</h1>
                    <div>No data</div>
                </div>
                )
        } else {
            return (
                <div>
                    <h1>Room: {room_number}</h1>
                    <table className="table mt-5 text-center">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Sensor Name</th>
                                <th>Amount</th>
                                <th>Dimension</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            {sensors.map((s, pos) => (
                                <tr>
                                    <td>{s.sensor_id}</td>
                                    <td>{s.sensor_name}</td>
                                    <td>{s.data}</td>
                                    <td>{s.data_dimension}</td>
                                    <td>{s.data_timestamp}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            );
        }
    }

}

/*
<ul className="list-group">
                        { sensors.map( s => (
                            <li className="list-group-item" key={s.id}>
                                {s.sensorname}
                            </li>
                        ))}
                    </ul>
*/


/*const db = require('../config/index');

module.exports = function (app) {
    app.get("/api/room/:number", function (req, res) {
        res.set('Access-Control-Allow-Origin', '*')
        db.any(
            "SELECT sensor.sensorname FROM sensor INNER JOIN controller_sensor ON controller_sensor.id_sensor=sensor.id " +
            "WHERE controller_sensor.room = " + req.params.number + ":: varchar"
        )
            .then(function (data) {
                res.json({
                    status: "success",
                    data: data,
                });
            })
            .catch(function (err) {
                return next(err);
            });
    });
};*/
