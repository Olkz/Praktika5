import React, { Component } from "react";
import axios from 'axios';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom"; //Switch vana versiooniga

export default class continentcountries extends React.Component {
    state = {
        countrycities: '',
        cities: []
    };

    readData() {
        this.setState({ countrycities: this.props.match.params.country })
        axios.get(`http://localhost:8000/api/country/${this.props.match.params.country}/cities`) //getcountrydata
            .then(res => {
                this.setState({ cities: res.data.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    componentDidMount() {
        this.readData()
    }

    componentDidUpdate(prevProps) {
        if (prevProps.match.params.country !== this.props.match.params.country) {
            this.readData()
        }
    }

    render() {
        const { countrycities, cities } = this.state;
        if (cities.length === 0) {
            return (
                <div>
                    <h1> Country: {countrycities}</h1>
                    <div>No data</div>
                </div>
                )
        } else {
            return (
             //   <Router>
                    <div>
                        <h1>Cities of {countrycities}</h1>
                        <table className="table mt-3 text-center">
                            <thead>
                                <tr>
                                    <th>City Name</th>
                                    <th>District</th>
                                    <th>Population</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cities.map((cc, pos) => (
                                    <tr>
                                        <td>{cc.name}</td>
                                        <td>{cc.district}</td>
                                        <td>{cc.population}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                    
             //   </Router>
            );
        }
    }

}

