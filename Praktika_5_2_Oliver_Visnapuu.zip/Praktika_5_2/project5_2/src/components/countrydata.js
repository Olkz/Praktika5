import React, { Component } from "react";
import axios from 'axios';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom"; //Switch vana versiooniga
import CountryCities from '../components/countrycities'; //praktika 4 DB päring

export default class continentcountries extends React.Component {
    state = {
        country: '',
        cattributes: []
    };

    readData() {
        this.setState({ country: this.props.match.params.country })
        axios.get(`http://localhost:8000/api/continent/${this.props.match.params.continent}/countries/${this.props.match.params.country}/data`) //getcountrydata
            .then(res => {
                this.setState({ cattributes: res.data.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    componentDidMount() {
        this.readData()
    }

    componentDidUpdate(prevProps) {
        if (prevProps.match.params.country !== this.props.match.params.country) {
            this.readData()
        }
    }

    render() {
        const { country, cattributes } = this.state;
        if (cattributes.length === 0) {
            return (
                <div>
                    <h1> Country: {country}</h1>
                    <div>No data</div>
                </div>
                )
        } else {
            return (
                <Router>
                    <div>
                        <h1>Country: {country}</h1>
                        <table className="table mt-7 text-center">
                            <thead>
                                <tr>
                                    <th>Country</th>
                                    <th>Code</th>
                                    <th>Surface Area</th>
                                    <th>Population</th>
                                    <th>Head of State</th>
                                    <th>Capital</th>
                                    <th>Population of Capital</th>
                                </tr>
                            </thead>
                            <tbody>
                                {cattributes.map((c, pos) => (
                                    <tr>
                                        <td>{c.name}</td>
                                        <td>{c.code}</td>
                                        <td>{c.surfacearea}</td>
                                        <td>{c.population}</td>
                                        <td>{c.headofstate}</td>
                                        <td>{c.capital}</td>
                                        <td>{c.capital_population}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        <Link className="nav-link" to={`/country/${this.props.match.params.country}/cities`}>Click to see cities</Link>
                        <Switch> 
                            <Route path="/country/:country/cities" component={CountryCities} />
                        </Switch>
                    </div>
                    
                </Router>
            );
        }
    }

}

