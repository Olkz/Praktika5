import React, { Component } from "react";
import axios from 'axios';
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom"; //Switch vana versiooniga
import CountryData from '../components/countrydata'; //praktika 4 DB päring

export default class continentcountries extends React.Component {
    state = {
        continent: '',
        countries: []
    };

    readData() {
        this.setState({ continent: this.props.match.params.continent })
        axios.get(`http://localhost:8000/api/continent/${this.props.match.params.continent}/countries`) //getcountriescontinent
            .then(res => {
                this.setState({ countries: res.data.data });
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    componentDidMount() {
        this.readData()
    }

    componentDidUpdate(prevProps) {
        if (prevProps.match.params.continent !== this.props.match.params.continent) {
            this.readData()
        }
    }

    render() {
        const { continent, countries } = this.state;
        if (countries.length === 0) {
            return (
                <div>
                    <h1> Continent: {continent}</h1>
                    <div>No data</div>
                </div>
                )
        } else {
            return (
           //     <Router>
                    <div>
                        <h1>Continent: {continent}</h1>
                        <table className="table mt-2 text-center">
                            <thead>
                                <tr>
                                    <th>Country</th>
                                    <th>Capital</th>
                                </tr>
                            </thead>
                            <tbody>
                                {countries.map((s, pos) => (
                                    <tr>
                                        <td>
                                            <li className="nav-item">
                                                <Link className="nav-link" to={`/country/${s.country}`}>{s.country}</Link>
                                            </li>
                                        </td>
                                        <td>{s.capital}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                        
                    </div>
            //    </Router>
            );
        }
    }

}

/* <div className="container">
                            <div className="row">
                                <div className="col-md-12">
                                    <Switch> 
                                        <Route path="/continent/:country" component={CountryData} />
                                    </Switch>
                                </div>
                            </div>
                        </div>

                        */